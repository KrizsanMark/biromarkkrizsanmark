﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PetsApi.Models;

namespace PetsApi.Controllers
{
    [Route("Fajta")]
    [ApiController]
    public class FajtaController : ControllerBase
    {
        private readonly PetsContext _context;

        public FajtaController(PetsContext context)
        {
            _context = context;
        }

        [HttpGet("GetAll")]

        public async Task<ActionResult<Fajtum>> Get() 
        {
            var fajta = await _context.Fajta.ToListAsync();
            if (fajta != null) 
            {
                return Ok(fajta);
            }
            return BadRequest();
        }
    }
}
