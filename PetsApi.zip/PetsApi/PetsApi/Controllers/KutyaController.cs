﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PetsApi.Models;

namespace PetsApi.Controllers
{
    [Route("Kutya")]
    [ApiController]
    public class KutyaController : ControllerBase
    {
        private readonly PetsContext _context;

        public KutyaController(PetsContext context)
        {
            _context = context;
        }

        [HttpGet("GetById")]
        public async Task<ActionResult<Kutya>> GetByid(int id) 
        { 
            var kutya = await _context.Kutyas.FirstOrDefaultAsync(x => x.Id == id);
            if (kutya != null)
            {
            return Ok(kutya);
                
            }
            return StatusCode(404,new {message = "nincs ilyen azonositoju kutya"});
        }
        [HttpDelete("DelById")]
        public async Task<ActionResult<Kutya>> DelByid(int id)
        {
            var delkuty = await _context.Kutyas.FirstOrDefaultAsync(y => y.Id == id);
            if (delkuty != null)
            {
                _context.Kutyas.Remove(delkuty);
                await _context.SaveChangesAsync();
                return StatusCode(200, new { message= "sikeres törlés" });
            }
            return StatusCode(404, new { message = "nincs mit törölni" });
        }
        [HttpGet("GetAllDTO")]
        public async Task<ActionResult<Kutya>> GetAllDTO()
        {
            var allDTO = await _context.Kutyas.Select(kuty => new { kuty.Id, kuty.Nev, kuty.Eletkor, kuty.Fajta, kuty.Gazda }).ToListAsync();

            if (allDTO != null)
            {
                return Ok(allDTO);
            }

            return StatusCode(400, new { message = "Unable to connect to any of the specified MySql hosts" });
        }

        [HttpPost("Add")]
        public async Task<ActionResult<Kutya>> Add(Createkutydto createkutydto)
        {
            var kutyaa = new Kutya
            {
                Nev = createkutydto.Nev,
                FajtaId = createkutydto.FajtaId,
                GazdaId = createkutydto.GazdaId,
                Eletkor = createkutydto.Eletkor,
                Rogzitve = createkutydto.Rogzitve,
            };

            if (kutyaa != null)
            {
                await _context.Kutyas.AddAsync(kutyaa);
                await _context.SaveChangesAsync();
                return StatusCode(200, new { message = "Sikeres rögzítés." });
            }

            return StatusCode(404, new { message = "Nem érkezett adat." });
        }



    }
}
