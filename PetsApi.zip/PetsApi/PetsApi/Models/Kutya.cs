﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace PetsApi.Models;

public partial class Kutya
{
    public int Id { get; set; }

    public string Nev { get; set; } = null!;

    public int FajtaId { get; set; }

    public int GazdaId { get; set; }

    public int Eletkor { get; set; }

    public DateTime Rogzitve { get; set; }
    [JsonIgnore]
    public virtual Fajtum Fajta { get; set; } = null!;
    [JsonIgnore]
    public virtual Gazdum Gazda { get; set; } = null!;
}
