﻿namespace PetsApi.Models
{
    public record Createkutydto(string Nev, int FajtaId, int GazdaId, int Eletkor, DateTime Rogzitve );
}
